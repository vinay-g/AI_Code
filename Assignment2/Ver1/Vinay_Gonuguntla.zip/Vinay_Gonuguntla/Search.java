
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author vinay
 */
public interface Search {
   abstract public boolean action( ArrayList<Node> mainArray);
}
